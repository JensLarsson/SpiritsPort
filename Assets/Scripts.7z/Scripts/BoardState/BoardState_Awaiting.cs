﻿using UnityEngine;

internal class BoardState_Awaiting : BoardState
{
    public override void EnterState(GameBoard gameBoard, (int x, int y)[] positions = null)
    {

    }

    public override void Interact(GameBoard gameBoard, Vector2Int position)
    {

    }
    public override void Update(GameBoard gameBoard, Vector2Int boardPosition)
    {

    }
}